<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title">All Product Info</h4>
                    <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Category Name</th>
                            <th>Product Name</th>
                            <th>Product Image</th>
                            <th>Selling Price</th>
                            <th>Stock Amount</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($product->category->name); ?></td>
                                <td><?php echo e($product->name); ?></td>
                                <td><img src="<?php echo e(asset($product->image)); ?>" alt="" width="50" height="40"/></td>
                                <td><?php echo e($product->selling_price); ?></td>
                                <td><?php echo e($product->stock_amount); ?></td>
                                <td><?php echo e($product->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('product.detail', ['id' => $product->id])); ?>" class="btn btn-primary btn-sm">
                                        <i class="fa fa-book-open"></i>
                                    </a>
                                    <a href="<?php echo e(route('product.edit', ['id' => $product->id])); ?>" class="btn btn-success btn-sm">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="<?php echo e(route('product.delete', ['id' => $product->id])); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure to delete this..');">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\ecommerce\resources\views/admin/product/manage.blade.php ENDPATH**/ ?>