<h1><?php echo e($data['title']); ?></h1>
<h2>Welcome <?php echo e($data['name']); ?>, Congratulation for your order.</h2>
<h1>Your Total Order : <?php echo e($data['total']); ?></h1>
<p>Thank You.</p>
<?php /**PATH C:\xampp\htdocs\ecommerce-b2\resources\views/email/order.blade.php ENDPATH**/ ?>