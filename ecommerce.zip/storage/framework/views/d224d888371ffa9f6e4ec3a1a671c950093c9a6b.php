<h1>Hello PDF</h1>
<?php /**PATH C:\xampp\htdocs\ecommerce-b2\resources\views/page.blade.php ENDPATH**/ ?>