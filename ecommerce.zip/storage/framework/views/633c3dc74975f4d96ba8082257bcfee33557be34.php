<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">All Sub Category Info</h4>
                    <p class="text-success text-center"><?php echo e(Session::get('message')); ?></p>
                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Category Name</th>
                            <th>Sub Category Name</th>
                            <th>Description</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($sub_category->category->name); ?></td>
                            <td><?php echo e($sub_category->name); ?></td>
                            <td><?php echo e($sub_category->description); ?></td>
                            <td>
                                <img src="<?php echo e(asset($sub_category->image)); ?>" alt="" height="50" width="80"/>
                            </td>
                            <td><?php echo e($sub_category->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                            <td>
                                <a href="<?php echo e(route('sub-category.edit', ['id' => $sub_category->id])); ?>" class="btn btn-success btn-sm">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <a href="" class="btn btn-danger btn-sm" onclick="event.preventDefault(); confirm('Are you sure?'); document.getElementById('subCategoryDeleteForm<?php echo e($sub_category->id); ?>').submit();">
                                    <i class="fa fa-trash"></i>
                                </a>
                                <form action="<?php echo e(route('sub-category.delete', ['id' => $sub_category->id])); ?>" method="POST" id="subCategoryDeleteForm<?php echo e($sub_category->id); ?>">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\ecommerce\resources\views/admin/sub-category/manage.blade.php ENDPATH**/ ?>