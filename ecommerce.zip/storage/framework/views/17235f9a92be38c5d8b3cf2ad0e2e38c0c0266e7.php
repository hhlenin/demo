<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title">All Brand Info</h4>
                    <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Brand Name</th>
                            <th>Brand Description</th>
                            <th>Brand Image</th>
                            <th>Publication Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>


                        <tbody>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($brand->name); ?></td>
                                <td><?php echo e($brand->description); ?></td>
                                <td><img src="<?php echo e(asset($brand->image)); ?>" alt="" height="50" width="80"/></td>
                                <td><?php echo e($brand->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('brand.edit', ['id' => $brand->id])); ?>" class="btn btn-success btn-sm">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="<?php echo e(route('brand.delete', ['id' => $brand->id])); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure to delete this..');">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce-b2\resources\views/admin/brand/manage.blade.php ENDPATH**/ ?>