<h1>This is login page</h1>
<?php /**PATH C:\xampp\htdocs\ecommerce-b2\resources\views/admin/login/login.blade.php ENDPATH**/ ?>