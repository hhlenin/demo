<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Edit Order Info</h4>
                    <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                    <form action="<?php echo e(route('admin.order-update', ['id' => $order->id])); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row mb-4">
                            <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Order Total</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" value="<?php echo e($order->order_total); ?>" name="order_total" readonly id="horizontal-firstname-input"/>
                            </div>
                        </div>
                        <div class="form-group row mb-4">
                            <label for="horizontal-email-input" class="col-sm-3 col-form-label">Delivery Address</label>
                            <div class="col-sm-9">
                                <textarea class="form-control" name="delivery_address" id="horizontal-email-input"><?php echo e($order->delivery_address); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row mb-4">
                            <label for="horizontal-password-input" class="col-sm-3 col-form-label">Order Status</label>
                            <div class="col-sm-9">
                                <select class="form-control" name="order_status" required>
                                    <option value="" disabled selected> -- Select Order Status -- </option>
                                    <option value="Pending" <?php echo e($order->order_status == 'Pending' ? 'selected' : ''); ?>> Pending </option>
                                    <option value="Processing" <?php echo e($order->order_status == 'Processing' ? 'selected' : ''); ?>> Processing </option>
                                    <option value="Complete" <?php echo e($order->order_status == 'Complete' ? 'selected' : ''); ?>> Complete </option>
                                    <option value="Cancel" <?php echo e($order->order_status == 'Cancel' ? 'selected' : ''); ?>> Cancel </option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row mb-4">
                            <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Payment Amount</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" value="<?php echo e($order->order_total); ?>" name="payment_amount" id="horizontal-firstname-input"/>
                            </div>
                        </div>
                        <div class="form-group row mb-4">
                            <label for="horizontal-password-input" class="col-sm-3 col-form-label">Payment Status</label>
                            <div class="col-sm-9">
                                <select class="form-control" name="payment_status" required>
                                    <option value="" disabled selected> -- Select Payment Status -- </option>
                                    <option value="Pending" <?php echo e($order->order_status == 'Pending' ? 'selected' : ''); ?>> Pending </option>
                                    <option value="Processing" <?php echo e($order->order_status == 'Processing' ? 'selected' : ''); ?>> Processing </option>
                                    <option value="Complete" <?php echo e($order->order_status == 'Complete' ? 'selected' : ''); ?>> Complete </option>
                                    <option value="Cancel" <?php echo e($order->order_status == 'Cancel' ? 'selected' : ''); ?>> Cancel </option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row justify-content-end">
                            <div class="col-sm-9">
                                <div>
                                    <button type="submit" class="btn btn-primary w-md">Update Order Info</button>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce-b2\resources\views/admin/order/edit.blade.php ENDPATH**/ ?>