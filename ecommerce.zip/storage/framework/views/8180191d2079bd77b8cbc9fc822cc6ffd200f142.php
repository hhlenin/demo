<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Order Basic Info</h4>
                    <hr/>
                    <table class="table table-bordered table-hover">
                        <tr>
                            <th>Order Id</th>
                            <td><?php echo e($order->id); ?></td>
                        </tr>
                        <tr>
                            <th>Order Total</th>
                            <td><?php echo e(number_format($order->order_total)); ?></td>
                        </tr>
                        <tr>
                            <th>Tax Amount</th>
                            <td><?php echo e(number_format($order->tax_amount)); ?></td>
                        </tr>
                        <tr>
                            <th>Shipping Cost</th>
                            <td><?php echo e(number_format($order->shipping_cost)); ?></td>
                        </tr>
                        <tr>
                            <th>Order Status</th>
                            <td><?php echo e($order->order_status); ?></td>
                        </tr>
                        <tr>
                            <th>Order Date</th>
                            <td><?php echo e($order->order_date); ?></td>
                        </tr>
                        <tr>
                            <th>Payment Status</th>
                            <td><?php echo e($order->payment_status); ?></td>
                        </tr>
                        <tr>
                            <th>Payment Type</th>
                            <td><?php echo e($order->payment_type == 1 ? 'Cash On Delivery' : 'Online Payment Gateway'); ?></td>
                        </tr>
                        <tr>
                            <th>Payment Amount</th>
                            <td><?php echo e(number_format($order->payment_amount)); ?></td>
                        </tr>
                        <tr>
                            <th>Payment Date</th>
                            <td><?php echo e($order->payment_date); ?></td>
                        </tr>
                        <tr>
                            <th>Delivery Address</th>
                            <td><?php echo e($order->delivery_address); ?></td>
                        </tr>
                        <tr>
                            <th>Delivery Date</th>
                            <td><?php echo e($order->delivery_date); ?></td>
                        </tr>
                        <tr>
                            <th>Online Transaction Id</th>
                            <td><?php echo e($order->transaction_id); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h4>Order Customer Detail</h4>
                    <hr/>
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>Customer Name </th>
                            <th>Customer Email </th>
                            <th>Customer Mobile </th>
                            <th>Customer Address </th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td><?php echo e($order->customer->name); ?></td>
                            <td><?php echo e($order->customer->email); ?></td>
                            <td><?php echo e($order->customer->mobile); ?></td>
                            <td><?php echo e($order->customer->address); ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Order Product Info</h4>
                    <hr/>
                    <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                    <table class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Product Id</th>
                            <th>Product Name</th>
                            <th>Product Price</th>
                            <th>Product Quantity</th>
                            <th>Total Price</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($orderDetail->product_id); ?></td>
                            <td><?php echo e($orderDetail->product_name); ?></td>
                            <td><?php echo e($orderDetail->product_price); ?></td>
                            <td><?php echo e($orderDetail->product_quantity); ?></td>
                            <td><?php echo e($orderDetail->product_quantity * $orderDetail->product_price); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\ecommerce-b2\resources\views/admin/order/detail.blade.php ENDPATH**/ ?>